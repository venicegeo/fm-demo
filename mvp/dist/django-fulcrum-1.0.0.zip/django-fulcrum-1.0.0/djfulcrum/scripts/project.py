# Copyright 2016, RadiantBlue Technologies, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from __future__ import absolute_import
import os
import argparse


def create_mvp(name='mvp', dir='.'):
    proj_root = os.path.join(dir, name)
    proj_dir = os.path.join(proj_root, name)
    if not os.path.exists(dir):
        os.mkdir(dir)
    if not os.path.exists(proj_root):
        os.mkdir(proj_root)
    if not os.path.exists(proj_dir):
        os.mkdir(proj_dir)
    workspace = os.path.dirname(os.path.abspath(__file__))
    file_dir = os.path.join(workspace, 'mvp')
    for file_name in os.listdir(file_dir):
        new_file = os.path.join(proj_dir, file_name)
        copy_template(os.path.join(file_dir, file_name), new_file, name)
    copy_template(os.path.join(proj_root, 'manage.py'), proj_root, name)

def copy_template(template, new_file, name):
    """
    Args:
        template: The absoulute path to the template.
        new_file: The absolute path to the new file.
        name: The name of the new project

    Returns: None

    """
    if os.path.isfile(new_file):
        print("Not writing file {}, because it already exists.".format(new_file))
    else:
        with open(template, 'r') as temp_file:
            data = temp_file.read()
        data.replace('mvp',name)
        with open(new_file, 'w') as proj_file:
            proj_file.write(data)

def main():
    parser = argparse.ArgumentParser(description='Script to create a minimal django project,'
                                                 'for use with Django-Fulcrum.')
    parser.add_argument('-dir', default='.', help='Location to store the project.')
    parser.add_argument('-name', default='mvp', help='The name of the project.')
    args = parser.parse_args()
    create_mvp(name=args.name, dir=args.dir)

if __name__ == "__main__":
    main()